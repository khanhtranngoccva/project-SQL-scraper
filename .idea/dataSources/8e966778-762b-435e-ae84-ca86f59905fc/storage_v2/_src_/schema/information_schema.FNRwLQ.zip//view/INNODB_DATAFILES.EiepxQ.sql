CREATE VIEW INNODB_DATAFILES AS
SELECT get_dd_tablespace_private_data(`ts`.`se_private_data`, 'id') AS `SPACE`, `ts_files`.`file_name` AS `PATH`
FROM (`mysql`.`tablespace_files` `ts_files` JOIN `mysql`.`tablespaces` `ts`
      ON ((`ts`.`id` = `ts_files`.`tablespace_id`)))
WHERE ((`ts`.`se_private_data` IS NOT NULL) AND (`ts`.`engine` = 'InnoDB') AND (`ts`.`name` <> 'mysql') AND
       (`ts`.`name` <> 'innodb_temporary'));

