CREATE VIEW REFERENTIAL_CONSTRAINTS AS
SELECT `cat`.`name`                             AS `CONSTRAINT_CATALOG`,
       `sch`.`name`                             AS `CONSTRAINT_SCHEMA`,
       (`fk`.`name` COLLATE utf8mb3_tolower_ci) AS `CONSTRAINT_NAME`,
       `fk`.`referenced_table_catalog`          AS `UNIQUE_CONSTRAINT_CATALOG`,
       `fk`.`referenced_table_schema`           AS `UNIQUE_CONSTRAINT_SCHEMA`,
       `fk`.`unique_constraint_name`            AS `UNIQUE_CONSTRAINT_NAME`,
       `fk`.`match_option`                      AS `MATCH_OPTION`,
       `fk`.`update_rule`                       AS `UPDATE_RULE`,
       `fk`.`delete_rule`                       AS `DELETE_RULE`,
       `tbl`.`name`                             AS `TABLE_NAME`,
       `fk`.`referenced_table_name`             AS `REFERENCED_TABLE_NAME`
FROM (((`mysql`.`foreign_keys` `fk` JOIN `mysql`.`tables` `tbl`
        ON ((`fk`.`table_id` = `tbl`.`id`))) JOIN `mysql`.`schemata` `sch`
       ON ((`fk`.`schema_id` = `sch`.`id`))) JOIN `mysql`.`catalogs` `cat` ON ((`cat`.`id` = `sch`.`catalog_id`)))
WHERE ((0 <> can_access_table(`sch`.`name`, `tbl`.`name`)) AND (0 <> is_visible_dd_object(`tbl`.`hidden`)));

