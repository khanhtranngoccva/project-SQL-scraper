CREATE VIEW SCHEMATA AS
SELECT (`cat`.`name` COLLATE utf8mb3_tolower_ci) AS `CATALOG_NAME`,
       (`sch`.`name` COLLATE utf8mb3_tolower_ci) AS `SCHEMA_NAME`,
       `cs`.`name`                               AS `DEFAULT_CHARACTER_SET_NAME`,
       `col`.`name`                              AS `DEFAULT_COLLATION_NAME`,
       NULL                                      AS `SQL_PATH`,
       `sch`.`default_encryption`                AS `DEFAULT_ENCRYPTION`
FROM (((`mysql`.`schemata` `sch` JOIN `mysql`.`catalogs` `cat`
        ON ((`cat`.`id` = `sch`.`catalog_id`))) JOIN `mysql`.`collations` `col`
       ON ((`sch`.`default_collation_id` = `col`.`id`))) JOIN `mysql`.`character_sets` `cs`
      ON ((`col`.`character_set_id` = `cs`.`id`)))
WHERE (0 <> can_access_database(`sch`.`name`));

