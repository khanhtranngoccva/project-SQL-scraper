CREATE VIEW PARTITIONS AS
SELECT (`cat`.`name` COLLATE utf8mb3_tolower_ci)                                                                     AS `TABLE_CATALOG`,
       (`sch`.`name` COLLATE utf8mb3_tolower_ci)                                                                     AS `TABLE_SCHEMA`,
       `tbl`.`name`                                                                                                  AS `TABLE_NAME`,
       `part`.`name`                                                                                                 AS `PARTITION_NAME`,
       `sub_part`.`name`                                                                                             AS `SUBPARTITION_NAME`,
       (`part`.`number` + 1)                                                                                         AS `PARTITION_ORDINAL_POSITION`,
       (`sub_part`.`number` + 1)                                                                                     AS `SUBPARTITION_ORDINAL_POSITION`,
       (CASE `tbl`.`partition_type`
            WHEN 'HASH' THEN 'HASH'
            WHEN 'RANGE' THEN 'RANGE'
            WHEN 'LIST' THEN 'LIST'
            WHEN 'AUTO' THEN 'AUTO'
            WHEN 'KEY_51' THEN 'KEY'
            WHEN 'KEY_55' THEN 'KEY'
            WHEN 'LINEAR_KEY_51' THEN 'LINEAR KEY'
            WHEN 'LINEAR_KEY_55' THEN 'LINEAR KEY'
            WHEN 'LINEAR_HASH' THEN 'LINEAR HASH'
            WHEN 'RANGE_COLUMNS' THEN 'RANGE COLUMNS'
            WHEN 'LIST_COLUMNS' THEN 'LIST COLUMNS'
            ELSE NULL END)                                                                                           AS `PARTITION_METHOD`,
       (CASE `tbl`.`subpartition_type`
            WHEN 'HASH' THEN 'HASH'
            WHEN 'RANGE' THEN 'RANGE'
            WHEN 'LIST' THEN 'LIST'
            WHEN 'AUTO' THEN 'AUTO'
            WHEN 'KEY_51' THEN 'KEY'
            WHEN 'KEY_55' THEN 'KEY'
            WHEN 'LINEAR_KEY_51' THEN 'LINEAR KEY'
            WHEN 'LINEAR_KEY_55' THEN 'LINEAR KEY'
            WHEN 'LINEAR_HASH' THEN 'LINEAR HASH'
            WHEN 'RANGE_COLUMNS' THEN 'RANGE COLUMNS'
            WHEN 'LIST_COLUMNS' THEN 'LIST COLUMNS'
            ELSE NULL END)                                                                                           AS `SUBPARTITION_METHOD`,
       `tbl`.`partition_expression_utf8`                                                                             AS `PARTITION_EXPRESSION`,
       `tbl`.`subpartition_expression_utf8`                                                                          AS `SUBPARTITION_EXPRESSION`,
       `part`.`description_utf8`                                                                                     AS `PARTITION_DESCRIPTION`,
       internal_table_rows(`sch`.`name`, `tbl`.`name`, IF((`tbl`.`partition_type` IS NULL), `tbl`.`engine`, ''),
                           `tbl`.`se_private_id`, (`tbl`.`hidden` <> 'Visible'), IF((`sub_part`.`name` IS NULL),
                                                                                    IF((`part`.`name` IS NULL),
                                                                                       `tbl`.`se_private_data`,
                                                                                       `part_ts`.`se_private_data`),
                                                                                    `sub_part_ts`.`se_private_data`), 0,
                           0,
                           IFNULL(`sub_part`.`name`, `part`.`name`))                                                 AS `TABLE_ROWS`,
       internal_avg_row_length(`sch`.`name`, `tbl`.`name`, IF((`tbl`.`partition_type` IS NULL), `tbl`.`engine`, ''),
                               `tbl`.`se_private_id`, (`tbl`.`hidden` <> 'Visible'), IF((`sub_part`.`name` IS NULL),
                                                                                        IF((`part`.`name` IS NULL),
                                                                                           `tbl`.`se_private_data`,
                                                                                           `part_ts`.`se_private_data`),
                                                                                        `sub_part_ts`.`se_private_data`),
                               0, 0,
                               IFNULL(`sub_part`.`name`, `part`.`name`))                                             AS `AVG_ROW_LENGTH`,
       internal_data_length(`sch`.`name`, `tbl`.`name`, IF((`tbl`.`partition_type` IS NULL), `tbl`.`engine`, ''),
                            `tbl`.`se_private_id`, (`tbl`.`hidden` <> 'Visible'), IF((`sub_part`.`name` IS NULL),
                                                                                     IF((`part`.`name` IS NULL),
                                                                                        `tbl`.`se_private_data`,
                                                                                        `part_ts`.`se_private_data`),
                                                                                     `sub_part_ts`.`se_private_data`),
                            0, 0,
                            IFNULL(`sub_part`.`name`, `part`.`name`))                                                AS `DATA_LENGTH`,
       internal_max_data_length(`sch`.`name`, `tbl`.`name`, IF((`tbl`.`partition_type` IS NULL), `tbl`.`engine`, ''),
                                `tbl`.`se_private_id`, (`tbl`.`hidden` <> 'Visible'), IF((`sub_part`.`name` IS NULL),
                                                                                         IF((`part`.`name` IS NULL),
                                                                                            `tbl`.`se_private_data`,
                                                                                            `part_ts`.`se_private_data`),
                                                                                         `sub_part_ts`.`se_private_data`),
                                0, 0,
                                IFNULL(`sub_part`.`name`, `part`.`name`))                                            AS `MAX_DATA_LENGTH`,
       internal_index_length(`sch`.`name`, `tbl`.`name`, IF((`tbl`.`partition_type` IS NULL), `tbl`.`engine`, ''),
                             `tbl`.`se_private_id`, (`tbl`.`hidden` <> 'Visible'), IF((`sub_part`.`name` IS NULL),
                                                                                      IF((`part`.`name` IS NULL),
                                                                                         `tbl`.`se_private_data`,
                                                                                         `part_ts`.`se_private_data`),
                                                                                      `sub_part_ts`.`se_private_data`),
                             0, 0,
                             IFNULL(`sub_part`.`name`, `part`.`name`))                                               AS `INDEX_LENGTH`,
       internal_data_free(`sch`.`name`, `tbl`.`name`, IF((`tbl`.`partition_type` IS NULL), `tbl`.`engine`, ''),
                          `tbl`.`se_private_id`, (`tbl`.`hidden` <> 'Visible'), IF((`sub_part`.`name` IS NULL),
                                                                                   IF((`part`.`name` IS NULL),
                                                                                      `tbl`.`se_private_data`,
                                                                                      `part_ts`.`se_private_data`),
                                                                                   `sub_part_ts`.`se_private_data`), 0,
                          0,
                          IFNULL(`sub_part`.`name`, `part`.`name`))                                                  AS `DATA_FREE`,
       `tbl`.`created`                                                                                               AS `CREATE_TIME`,
       internal_update_time(`sch`.`name`, `tbl`.`name`, IF((`tbl`.`partition_type` IS NULL), `tbl`.`engine`, ''),
                            `tbl`.`se_private_id`, (`tbl`.`hidden` <> 'Visible'), IF((`sub_part`.`name` IS NULL),
                                                                                     IF((`part`.`name` IS NULL),
                                                                                        `tbl`.`se_private_data`,
                                                                                        `part_ts`.`se_private_data`),
                                                                                     `sub_part_ts`.`se_private_data`),
                            0, 0,
                            IFNULL(`sub_part`.`name`, `part`.`name`))                                                AS `UPDATE_TIME`,
       internal_check_time(`sch`.`name`, `tbl`.`name`, IF((`tbl`.`partition_type` IS NULL), `tbl`.`engine`, ''),
                           `tbl`.`se_private_id`, (`tbl`.`hidden` <> 'Visible'), IF((`sub_part`.`name` IS NULL),
                                                                                    IF((`part`.`name` IS NULL),
                                                                                       `tbl`.`se_private_data`,
                                                                                       `part_ts`.`se_private_data`),
                                                                                    `sub_part_ts`.`se_private_data`), 0,
                           0,
                           IFNULL(`sub_part`.`name`, `part`.`name`))                                                 AS `CHECK_TIME`,
       internal_checksum(`sch`.`name`, `tbl`.`name`, IF((`tbl`.`partition_type` IS NULL), `tbl`.`engine`, ''),
                         `tbl`.`se_private_id`, (`tbl`.`hidden` <> 'Visible'), IF((`sub_part`.`name` IS NULL),
                                                                                  IF((`part`.`name` IS NULL),
                                                                                     `tbl`.`se_private_data`,
                                                                                     `part_ts`.`se_private_data`),
                                                                                  `sub_part_ts`.`se_private_data`), 0,
                         0,
                         IFNULL(`sub_part`.`name`, `part`.`name`))                                                   AS `CHECKSUM`,
       IF((`sub_part`.`name` IS NULL), IFNULL(`part`.`comment`, ''),
          IFNULL(`sub_part`.`comment`, ''))                                                                          AS `PARTITION_COMMENT`,
       IF((`part`.`name` IS NULL), '',
          internal_get_partition_nodegroup(IF((`sub_part`.`name` IS NULL), `part`.`options`,
                                              `sub_part`.`options`)))                                                AS `NODEGROUP`,
       IFNULL(`sub_part_ts`.`name`, `part_ts`.`name`)                                                                AS `TABLESPACE_NAME`
FROM ((((((`mysql`.`tables` `tbl` JOIN `mysql`.`schemata` `sch`
           ON ((`sch`.`id` = `tbl`.`schema_id`))) JOIN `mysql`.`catalogs` `cat`
          ON ((`cat`.`id` = `sch`.`catalog_id`))) LEFT JOIN `mysql`.`table_partitions` `part`
         ON ((`part`.`table_id` = `tbl`.`id`))) LEFT JOIN `mysql`.`table_partitions` `sub_part`
        ON ((`sub_part`.`parent_partition_id` = `part`.`id`))) LEFT JOIN `mysql`.`tablespaces` `part_ts`
       ON ((`part_ts`.`id` = `part`.`tablespace_id`))) LEFT JOIN `mysql`.`tablespaces` `sub_part_ts`
      ON (((`sub_part`.`tablespace_id` IS NOT NULL) AND (`sub_part_ts`.`id` = `sub_part`.`tablespace_id`))))
WHERE ((0 <> can_access_table(`sch`.`name`, `tbl`.`name`)) AND (0 <> is_visible_dd_object(`tbl`.`hidden`)) AND
       (`part`.`parent_partition_id` IS NULL));

