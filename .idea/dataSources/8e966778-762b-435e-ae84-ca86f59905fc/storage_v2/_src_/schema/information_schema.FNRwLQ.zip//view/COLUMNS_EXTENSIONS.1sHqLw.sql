CREATE VIEW COLUMNS_EXTENSIONS AS
SELECT `cat`.`name`                              AS `TABLE_CATALOG`,
       `sch`.`name`                              AS `TABLE_SCHEMA`,
       `tbl`.`name`                              AS `TABLE_NAME`,
       (`col`.`name` COLLATE utf8mb3_tolower_ci) AS `COLUMN_NAME`,
       `col`.`engine_attribute`                  AS `ENGINE_ATTRIBUTE`,
       `col`.`secondary_engine_attribute`        AS `SECONDARY_ENGINE_ATTRIBUTE`
FROM (((`mysql`.`columns` `col` JOIN `mysql`.`tables` `tbl`
        ON ((`col`.`table_id` = `tbl`.`id`))) JOIN `mysql`.`schemata` `sch`
       ON ((`tbl`.`schema_id` = `sch`.`id`))) JOIN `mysql`.`catalogs` `cat` ON ((`cat`.`id` = `sch`.`catalog_id`)))
WHERE ((0 <> internal_get_view_warning_or_error(`sch`.`name`, `tbl`.`name`, `tbl`.`type`, `tbl`.`options`)) AND
       (0 <> can_access_column(`sch`.`name`, `tbl`.`name`, `col`.`name`)) AND
       (0 <> is_visible_dd_object(`tbl`.`hidden`, (`col`.`hidden` NOT IN ('Visible', 'User')), `col`.`options`)));

