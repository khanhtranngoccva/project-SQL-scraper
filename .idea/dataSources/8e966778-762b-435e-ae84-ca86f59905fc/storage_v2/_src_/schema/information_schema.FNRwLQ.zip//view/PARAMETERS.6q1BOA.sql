CREATE VIEW PARAMETERS AS
SELECT (`cat`.`name` COLLATE utf8mb3_tolower_ci)                                                 AS `SPECIFIC_CATALOG`,
       (`sch`.`name` COLLATE utf8mb3_tolower_ci)                                                 AS `SPECIFIC_SCHEMA`,
       `rtn`.`name`                                                                              AS `SPECIFIC_NAME`,
       IF((`rtn`.`type` = 'FUNCTION'), (`prm`.`ordinal_position` - 1), `prm`.`ordinal_position`) AS `ORDINAL_POSITION`,
       IF(((`rtn`.`type` = 'FUNCTION') AND (`prm`.`ordinal_position` = 1)), NULL, `prm`.`mode`)  AS `PARAMETER_MODE`,
       IF(((`rtn`.`type` = 'FUNCTION') AND (`prm`.`ordinal_position` = 1)), NULL, `prm`.`name`)  AS `PARAMETER_NAME`,
       SUBSTRING_INDEX(SUBSTRING_INDEX(`prm`.`data_type_utf8`, '(', 1), ' ', 1)                  AS `DATA_TYPE`,
       internal_dd_char_length(`prm`.`data_type`, `prm`.`char_length`, `col`.`name`,
                               0)                                                                AS `CHARACTER_MAXIMUM_LENGTH`,
       internal_dd_char_length(`prm`.`data_type`, `prm`.`char_length`, `col`.`name`,
                               1)                                                                AS `CHARACTER_OCTET_LENGTH`,
       `prm`.`numeric_precision`                                                                 AS `NUMERIC_PRECISION`,
       IF((`prm`.`numeric_precision` IS NULL), NULL, IFNULL(`prm`.`numeric_scale`, 0))           AS `NUMERIC_SCALE`,
       `prm`.`datetime_precision`                                                                AS `DATETIME_PRECISION`,
       (CASE `prm`.`data_type`
            WHEN 'MYSQL_TYPE_STRING' THEN IF((`cs`.`name` = 'binary'), NULL, `cs`.`name`)
            WHEN 'MYSQL_TYPE_VAR_STRING' THEN IF((`cs`.`name` = 'binary'), NULL, `cs`.`name`)
            WHEN 'MYSQL_TYPE_VARCHAR' THEN IF((`cs`.`name` = 'binary'), NULL, `cs`.`name`)
            WHEN 'MYSQL_TYPE_TINY_BLOB' THEN IF((`cs`.`name` = 'binary'), NULL, `cs`.`name`)
            WHEN 'MYSQL_TYPE_MEDIUM_BLOB' THEN IF((`cs`.`name` = 'binary'), NULL, `cs`.`name`)
            WHEN 'MYSQL_TYPE_BLOB' THEN IF((`cs`.`name` = 'binary'), NULL, `cs`.`name`)
            WHEN 'MYSQL_TYPE_LONG_BLOB' THEN IF((`cs`.`name` = 'binary'), NULL, `cs`.`name`)
            WHEN 'MYSQL_TYPE_ENUM' THEN IF((`cs`.`name` = 'binary'), NULL, `cs`.`name`)
            WHEN 'MYSQL_TYPE_SET' THEN IF((`cs`.`name` = 'binary'), NULL, `cs`.`name`)
            ELSE NULL END)                                                                       AS `CHARACTER_SET_NAME`,
       (CASE `prm`.`data_type`
            WHEN 'MYSQL_TYPE_STRING' THEN IF((`cs`.`name` = 'binary'), NULL, `col`.`name`)
            WHEN 'MYSQL_TYPE_VAR_STRING' THEN IF((`cs`.`name` = 'binary'), NULL, `col`.`name`)
            WHEN 'MYSQL_TYPE_VARCHAR' THEN IF((`cs`.`name` = 'binary'), NULL, `col`.`name`)
            WHEN 'MYSQL_TYPE_TINY_BLOB' THEN IF((`cs`.`name` = 'binary'), NULL, `col`.`name`)
            WHEN 'MYSQL_TYPE_MEDIUM_BLOB' THEN IF((`cs`.`name` = 'binary'), NULL, `col`.`name`)
            WHEN 'MYSQL_TYPE_BLOB' THEN IF((`cs`.`name` = 'binary'), NULL, `col`.`name`)
            WHEN 'MYSQL_TYPE_LONG_BLOB' THEN IF((`cs`.`name` = 'binary'), NULL, `col`.`name`)
            WHEN 'MYSQL_TYPE_ENUM' THEN IF((`cs`.`name` = 'binary'), NULL, `col`.`name`)
            WHEN 'MYSQL_TYPE_SET' THEN IF((`cs`.`name` = 'binary'), NULL, `col`.`name`)
            ELSE NULL END)                                                                       AS `COLLATION_NAME`,
       `prm`.`data_type_utf8`                                                                    AS `DTD_IDENTIFIER`,
       `rtn`.`type`                                                                              AS `ROUTINE_TYPE`
FROM (((((`mysql`.`parameters` `prm` JOIN `mysql`.`routines` `rtn`
          ON ((`prm`.`routine_id` = `rtn`.`id`))) JOIN `mysql`.`schemata` `sch`
         ON ((`rtn`.`schema_id` = `sch`.`id`))) JOIN `mysql`.`catalogs` `cat`
        ON ((`cat`.`id` = `sch`.`catalog_id`))) JOIN `mysql`.`collations` `col`
       ON ((`prm`.`collation_id` = `col`.`id`))) JOIN `mysql`.`character_sets` `cs`
      ON ((`col`.`character_set_id` = `cs`.`id`)))
WHERE (0 <> can_access_routine(`sch`.`name`, `rtn`.`name`, `rtn`.`type`, `rtn`.`definer`, FALSE));

