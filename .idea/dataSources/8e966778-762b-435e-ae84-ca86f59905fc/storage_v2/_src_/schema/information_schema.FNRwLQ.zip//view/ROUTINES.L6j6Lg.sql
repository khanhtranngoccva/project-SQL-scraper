CREATE VIEW ROUTINES AS
SELECT `rtn`.`name`                                                                                           AS `SPECIFIC_NAME`,
       (`cat`.`name` COLLATE utf8mb3_tolower_ci)                                                              AS `ROUTINE_CATALOG`,
       (`sch`.`name` COLLATE utf8mb3_tolower_ci)                                                              AS `ROUTINE_SCHEMA`,
       `rtn`.`name`                                                                                           AS `ROUTINE_NAME`,
       `rtn`.`type`                                                                                           AS `ROUTINE_TYPE`,
       IF((`rtn`.`type` = 'PROCEDURE'), '', SUBSTRING_INDEX(SUBSTRING_INDEX(`rtn`.`result_data_type_utf8`, '(', 1), ' ',
                                                            1))                                               AS `DATA_TYPE`,
       internal_dd_char_length(`rtn`.`result_data_type`, `rtn`.`result_char_length`, `coll_result`.`name`,
                               0)                                                                             AS `CHARACTER_MAXIMUM_LENGTH`,
       internal_dd_char_length(`rtn`.`result_data_type`, `rtn`.`result_char_length`, `coll_result`.`name`,
                               1)                                                                             AS `CHARACTER_OCTET_LENGTH`,
       `rtn`.`result_numeric_precision`                                                                       AS `NUMERIC_PRECISION`,
       `rtn`.`result_numeric_scale`                                                                           AS `NUMERIC_SCALE`,
       `rtn`.`result_datetime_precision`                                                                      AS `DATETIME_PRECISION`,
       (CASE `rtn`.`result_data_type`
            WHEN 'MYSQL_TYPE_STRING' THEN IF((`cs_result`.`name` = 'binary'), NULL, `cs_result`.`name`)
            WHEN 'MYSQL_TYPE_VAR_STRING' THEN IF((`cs_result`.`name` = 'binary'), NULL, `cs_result`.`name`)
            WHEN 'MYSQL_TYPE_VARCHAR' THEN IF((`cs_result`.`name` = 'binary'), NULL, `cs_result`.`name`)
            WHEN 'MYSQL_TYPE_TINY_BLOB' THEN IF((`cs_result`.`name` = 'binary'), NULL, `cs_result`.`name`)
            WHEN 'MYSQL_TYPE_MEDIUM_BLOB' THEN IF((`cs_result`.`name` = 'binary'), NULL, `cs_result`.`name`)
            WHEN 'MYSQL_TYPE_BLOB' THEN IF((`cs_result`.`name` = 'binary'), NULL, `cs_result`.`name`)
            WHEN 'MYSQL_TYPE_LONG_BLOB' THEN IF((`cs_result`.`name` = 'binary'), NULL, `cs_result`.`name`)
            WHEN 'MYSQL_TYPE_ENUM' THEN IF((`cs_result`.`name` = 'binary'), NULL, `cs_result`.`name`)
            WHEN 'MYSQL_TYPE_SET' THEN IF((`cs_result`.`name` = 'binary'), NULL, `cs_result`.`name`)
            ELSE NULL END)                                                                                    AS `CHARACTER_SET_NAME`,
       (CASE `rtn`.`result_data_type`
            WHEN 'MYSQL_TYPE_STRING' THEN IF((`cs_result`.`name` = 'binary'), NULL, `coll_result`.`name`)
            WHEN 'MYSQL_TYPE_VAR_STRING' THEN IF((`cs_result`.`name` = 'binary'), NULL, `coll_result`.`name`)
            WHEN 'MYSQL_TYPE_VARCHAR' THEN IF((`cs_result`.`name` = 'binary'), NULL, `coll_result`.`name`)
            WHEN 'MYSQL_TYPE_TINY_BLOB' THEN IF((`cs_result`.`name` = 'binary'), NULL, `coll_result`.`name`)
            WHEN 'MYSQL_TYPE_MEDIUM_BLOB' THEN IF((`cs_result`.`name` = 'binary'), NULL, `coll_result`.`name`)
            WHEN 'MYSQL_TYPE_BLOB' THEN IF((`cs_result`.`name` = 'binary'), NULL, `coll_result`.`name`)
            WHEN 'MYSQL_TYPE_LONG_BLOB' THEN IF((`cs_result`.`name` = 'binary'), NULL, `coll_result`.`name`)
            WHEN 'MYSQL_TYPE_ENUM' THEN IF((`cs_result`.`name` = 'binary'), NULL, `coll_result`.`name`)
            WHEN 'MYSQL_TYPE_SET' THEN IF((`cs_result`.`name` = 'binary'), NULL, `coll_result`.`name`)
            ELSE NULL END)                                                                                    AS `COLLATION_NAME`,
       IF((`rtn`.`type` = 'PROCEDURE'), NULL,
          `rtn`.`result_data_type_utf8`)                                                                      AS `DTD_IDENTIFIER`,
       'SQL'                                                                                                  AS `ROUTINE_BODY`,
       IF(can_access_routine(`sch`.`name`, `rtn`.`name`, `rtn`.`type`, `rtn`.`definer`, TRUE), `rtn`.`definition_utf8`,
          NULL)                                                                                               AS `ROUTINE_DEFINITION`,
       NULL                                                                                                   AS `EXTERNAL_NAME`,
       `rtn`.`external_language`                                                                              AS `EXTERNAL_LANGUAGE`,
       'SQL'                                                                                                  AS `PARAMETER_STYLE`,
       IF((`rtn`.`is_deterministic` = 0), 'NO', 'YES')                                                        AS `IS_DETERMINISTIC`,
       `rtn`.`sql_data_access`                                                                                AS `SQL_DATA_ACCESS`,
       NULL                                                                                                   AS `SQL_PATH`,
       `rtn`.`security_type`                                                                                  AS `SECURITY_TYPE`,
       `rtn`.`created`                                                                                        AS `CREATED`,
       `rtn`.`last_altered`                                                                                   AS `LAST_ALTERED`,
       `rtn`.`sql_mode`                                                                                       AS `SQL_MODE`,
       `rtn`.`comment`                                                                                        AS `ROUTINE_COMMENT`,
       `rtn`.`definer`                                                                                        AS `DEFINER`,
       `cs_client`.`name`                                                                                     AS `CHARACTER_SET_CLIENT`,
       `coll_conn`.`name`                                                                                     AS `COLLATION_CONNECTION`,
       `coll_db`.`name`                                                                                       AS `DATABASE_COLLATION`
FROM ((((((((`mysql`.`routines` `rtn` JOIN `mysql`.`schemata` `sch`
             ON ((`rtn`.`schema_id` = `sch`.`id`))) JOIN `mysql`.`catalogs` `cat`
            ON ((`cat`.`id` = `sch`.`catalog_id`))) JOIN `mysql`.`collations` `coll_client`
           ON ((`coll_client`.`id` = `rtn`.`client_collation_id`))) JOIN `mysql`.`character_sets` `cs_client`
          ON ((`cs_client`.`id` = `coll_client`.`character_set_id`))) JOIN `mysql`.`collations` `coll_conn`
         ON ((`coll_conn`.`id` = `rtn`.`connection_collation_id`))) JOIN `mysql`.`collations` `coll_db`
        ON ((`coll_db`.`id` = `rtn`.`schema_collation_id`))) LEFT JOIN `mysql`.`collations` `coll_result`
       ON ((`coll_result`.`id` = `rtn`.`result_collation_id`))) LEFT JOIN `mysql`.`character_sets` `cs_result`
      ON ((`cs_result`.`id` = `coll_result`.`character_set_id`)))
WHERE (0 <> can_access_routine(`sch`.`name`, `rtn`.`name`, `rtn`.`type`, `rtn`.`definer`, FALSE));

