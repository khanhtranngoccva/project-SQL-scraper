CREATE VIEW SCHEMATA_EXTENSIONS AS
SELECT (`cat`.`name` COLLATE utf8mb3_tolower_ci) AS `CATALOG_NAME`,
       (`sch`.`name` COLLATE utf8mb3_tolower_ci) AS `SCHEMA_NAME`,
       get_dd_schema_options(`sch`.`options`)    AS `OPTIONS`
FROM (`mysql`.`schemata` `sch` JOIN `mysql`.`catalogs` `cat` ON ((`cat`.`id` = `sch`.`catalog_id`)))
WHERE (0 <> can_access_database(`sch`.`name`));

