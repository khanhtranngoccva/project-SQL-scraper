CREATE VIEW TABLE_CONSTRAINTS AS
SELECT (`cat`.`name` COLLATE utf8mb3_tolower_ci) AS `CONSTRAINT_CATALOG`,
       (`sch`.`name` COLLATE utf8mb3_tolower_ci) AS `CONSTRAINT_SCHEMA`,
       `constraints`.`CONSTRAINT_NAME`           AS `CONSTRAINT_NAME`,
       (`sch`.`name` COLLATE utf8mb3_tolower_ci) AS `TABLE_SCHEMA`,
       (`tbl`.`name` COLLATE utf8mb3_tolower_ci) AS `TABLE_NAME`,
       `constraints`.`CONSTRAINT_TYPE`           AS `CONSTRAINT_TYPE`,
       `constraints`.`ENFORCED`                  AS `ENFORCED`
FROM (((`mysql`.`tables` `tbl` JOIN `mysql`.`schemata` `sch`
        ON ((`tbl`.`schema_id` = `sch`.`id`))) JOIN `mysql`.`catalogs` `cat`
       ON ((`cat`.`id` = `sch`.`catalog_id`))) JOIN LATERAL (SELECT `idx`.`name`                                                AS `CONSTRAINT_NAME`,
                                                                    IF((`idx`.`type` = 'PRIMARY'), 'PRIMARY KEY', `idx`.`type`) AS `CONSTRAINT_TYPE`,
                                                                    'YES'                                                       AS `ENFORCED`
                                                             FROM `mysql`.`indexes` `idx`
                                                             WHERE ((`idx`.`table_id` = `tbl`.`id`) AND
                                                                    (`idx`.`type` IN ('PRIMARY', 'UNIQUE')) AND (0 <>
                                                                                                                 is_visible_dd_object(
                                                                                                                         `tbl`.`hidden`,
                                                                                                                         `idx`.`hidden`,
                                                                                                                         `idx`.`options`)))
                                                             UNION ALL
                                                             SELECT (`fk`.`name` COLLATE utf8mb3_tolower_ci) AS `CONSTRAINT_NAME`,
                                                                    'FOREIGN KEY'                            AS `CONSTRAINT_TYPE`,
                                                                    'YES'                                    AS `ENFORCED`
                                                             FROM `mysql`.`foreign_keys` `fk`
                                                             WHERE (`fk`.`table_id` = `tbl`.`id`)
                                                             UNION ALL
                                                             SELECT `cc`.`name`     AS `CONSTRAINT_NAME`,
                                                                    'CHECK'         AS `CONSTRAINT_TYPE`,
                                                                    `cc`.`enforced` AS `ENFORCED`
                                                             FROM `mysql`.`check_constraints` `cc`
                                                             WHERE (`cc`.`table_id` = `tbl`.`id`)) `constraints`)
WHERE ((0 <> can_access_table(`sch`.`name`, `tbl`.`name`)) AND (0 <> is_visible_dd_object(`tbl`.`hidden`)));

