CREATE DEFINER = `mysql.sys`@localhost VIEW version AS
SELECT '2.1.2' AS `sys_version`, VERSION() AS `mysql_version`;

